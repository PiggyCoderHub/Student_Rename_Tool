# 学生名单批量重命名工具

一个用于实验报告、作业文件、课程材料批量收缴整理的桌面工具。程序可以先导入学生名单，再根据学号、姓名、班级等信息批量匹配文件并重命名，适合教师、助教、班委或课程项目组整理学生提交材料。

本仓库已按 GitHub 上架方式整理：源码、启动脚本、依赖文件、使用说明、编码说明、Issue 模板和 GitHub Actions 检查文件均已补齐。所有中文 Markdown、Python、CSV、BAT 文件均按 UTF-8 方案处理，避免上传 GitHub 后出现中文乱码。

## 主要功能

- 学生名单导入：支持 `.xlsx`、`.xlsm`、`.xls`、`.csv`。
- 智能识别表格列：支持有表头、无表头、表头不在第一行等常见名单格式。
- 学号格式修复：处理 Excel 将学号显示为数字、`.0` 后缀或科学计数法导致的识别问题。
- 导入前确认：批量导入时先预览，可勾选是否导入，支持“全选 / 全不选 / 反选”。
- 重复学号处理：同一学号重复导入时自动更新原记录，不重复生成学生。
- 班级管理：可手动创建班级，也可根据名单中的班级列自动创建并分配。
- 文件匹配重命名：可从 `.docx` 内容、文件名中的学号或姓名识别提交人。
- 重名保护：输出目录中已存在同名文件时自动追加 `_1`、`_2`，避免覆盖。
- 运行日志：启动失败会生成 `run_error.log`，方便定位问题。

## 运行环境

建议环境：

- Windows 10 / Windows 11
- Python 3.8 或以上版本
- pip 可用

Python 依赖见 `requirements.txt`：

```txt
python-docx>=0.8.11
openpyxl>=3.0.0
xlrd>=2.0.1
```

说明：`tkinter` 是 Python 自带库，通常不需要单独安装。安装 Python 时建议勾选 `Add Python to PATH`。

## 快速启动

下载或克隆仓库后，在项目根目录双击：

```bat
启动程序.bat
```

如果无法启动，先双击：

```bat
安装依赖.bat
```

然后再次双击：

```bat
启动程序.bat
```

如果仍然打不开，双击：

```bat
调试启动.bat
```

调试启动会生成 `run_error.log`，把日志内容发给维护者即可定位问题。

备用入口：如果中文批处理文件在个别电脑上显示异常，可以双击 `START_HERE.bat`。备用入口为英文文件名，但程序界面仍是中文。

## 学生名单格式

推荐名单至少包含两列：

| 学号 | 姓名 | 班级 | 电话 | 邮箱 | 备注 |
| --- | --- | --- | --- | --- | --- |
| 202501010001 | 张三 | 计科1班 | 13800000000 | test@example.com |  |

其中必须有：

- 学号
- 姓名

可选字段：

- 班级
- 电话
- 邮箱
- 备注

仓库内已提供模板：

- `学生名单导入模板.xlsx`
- `学生名单导入模板.csv`
- `student_template.xlsx`
- `student_template.csv`

如果 Excel 打开 CSV 后中文异常，优先使用 `.xlsx` 模板。

## 使用流程

1. 双击 `启动程序.bat` 打开程序。
2. 进入学生信息管理。
3. 选择批量导入学生名单。
4. 选择 `.xlsx`、`.xlsm`、`.xls` 或 `.csv` 名单文件。
5. 在预览窗口检查识别结果。
6. 使用左侧“是否导入”列确认需要导入的学生。
7. 可使用“全选 / 全不选 / 反选”快速选择。
8. 点击“确认导入已选择”。
9. 进入批量重命名功能，选择学生提交文件所在文件夹。
10. 程序根据学号、姓名和文件内容进行匹配并输出重命名结果。

## 目录结构

```text
student-list-batch-renamer/
├─ gui_app.py                    # 图形界面主程序
├─ start_gui.py                  # GUI 启动器，负责依赖检查和错误日志
├─ main.py                       # 命令行模式入口
├─ student_db.py                 # 学生、班级、导入记录数据库逻辑
├─ excel_importer.py             # 学生名单 Excel/CSV 智能导入逻辑
├─ docx_reader.py                # Word 文档内容读取与学号/姓名提取
├─ batch_rename.py               # 通用批量重命名逻辑
├─ config.py                     # 重命名规则配置
├─ requirements.txt              # Python 依赖
├─ 启动程序.bat                  # 中文 GUI 启动脚本
├─ 安装依赖.bat                  # 中文依赖安装脚本
├─ 调试启动.bat                  # 中文调试启动脚本
├─ START_HERE.bat                # 英文备用启动脚本
├─ 学生名单导入模板.xlsx          # 中文 Excel 模板
├─ 学生名单导入模板.csv           # 中文 CSV 模板
├─ data/.gitkeep                 # 数据目录占位文件，本地数据库不上传
├─ docs/                         # 使用文档和上架说明
├─ .github/                      # GitHub Issue 模板和自动检查流程
├─ .gitignore                    # Git 忽略规则
├─ .gitattributes                # Git 文本与换行处理规则
└─ README.md                     # 项目说明
```

## 中文乱码处理说明

本项目已做以下处理：

- Markdown、Python 源码统一使用 UTF-8。
- CSV 模板使用 UTF-8 BOM，降低 Excel 打开中文乱码概率。
- BAT 文件使用 UTF-8 BOM，并在脚本开头执行 `chcp 65001`。
- ZIP 打包时使用 UTF-8 文件名，避免中文文件名解压后变成乱码。
- 保留英文备用启动文件 `START_HERE.bat`，用于极端环境兜底。
- `.editorconfig` 明确约束源码编码。
- GitHub Actions 会检查文本文件是否能按 UTF-8 解码。

注意：不要用旧版记事本或其他编辑器把 `.py`、`.md`、`.csv`、`.bat` 重新保存为 ANSI/GBK，否则上传 GitHub 后可能再次乱码。

## 常见问题

### 1. 双击启动没有反应

先运行 `安装依赖.bat`，再运行 `启动程序.bat`。如果仍失败，运行 `调试启动.bat`，查看 `run_error.log`。

### 2. 提示找不到 Python

说明 Python 没有加入系统 PATH。重新安装 Python，并勾选 `Add Python to PATH`。

### 3. 学生名单导入为空或识别错列

优先使用 `学生名单导入模板.xlsx`。如果使用自定义名单，确保至少包含“学号”和“姓名”。如果无表头，建议第一列为学号，第二列为姓名。

### 4. `.xls` 文件无法导入

`.xls` 需要 `xlrd`。可先运行 `安装依赖.bat`，或用 Excel/WPS 将文件另存为 `.xlsx`。

### 5. CSV 打开后中文乱码

优先使用 `.xlsx`。如果必须使用 CSV，请保存为 UTF-8 BOM 编码。

### 6. 文件没有被匹配到学生

建议学生提交文件名包含学号或姓名，例如：

```text
202501010001_张三_实验报告1.docx
张三_实验报告.docx
```

`.docx` 文件还可以读取文档内容进行匹配；旧版 `.doc` 文件不保证能读取正文内容，建议另存为 `.docx`。

## GitHub 上架建议

直接把本项目根目录上传到 GitHub。不要上传以下本地运行文件：

- `data/students.db`
- `run_error.log`
- `run_output.log`
- `__pycache__/`
- `.pyc` 文件

这些文件已写入 `.gitignore`。

## 版本说明

当前整理版本：GitHub 上架版，基于中文版 v6 无乱码版本继续整理。

主要处理：

- 补充 GitHub 标准 README。
- 补充 `.gitignore`、`.gitattributes`、`.editorconfig`。
- 补充 LICENSE、CHANGELOG、CONTRIBUTING。
- 补充使用手册、编码说明、上架步骤。
- 补充 GitHub Issue 模板和自动检查流程。
- 清理本地数据库、缓存文件、运行日志。
- 统一中文文件编码，降低乱码风险。

## License

本项目采用 MIT License。详见 `LICENSE`。
